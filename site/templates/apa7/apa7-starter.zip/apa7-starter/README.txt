APA 7 starter from purplelink.llc/templates/apa7/

main.tex        the minimal skeleton from the page
references.bib  one example entry; replace it with your own

Compile with pdfLaTeX, then Biber, then pdfLaTeX twice (or run latexmk -pdf main.tex).

In ModernTex: unzip, then File > Open the folder.
