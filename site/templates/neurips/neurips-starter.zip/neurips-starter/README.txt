NeurIPS starter from purplelink.llc/templates/neurips/

main.tex        the minimal skeleton from the page
references.bib  one example entry; replace it with your own

Compile with pdfLaTeX, then BibTeX, then pdfLaTeX twice (or run latexmk -pdf main.tex).

NeurIPS publishes a new style file each year. Download the current neurips_20XX.sty from the
NeurIPS call for papers, put it next to main.tex, and change the \usepackage line to match its name.

In ModernTex: unzip, then File > Open the folder.
