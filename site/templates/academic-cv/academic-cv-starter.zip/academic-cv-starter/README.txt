Academic CV starter from purplelink.llc/templates/academic-cv/

cv.tex   the CV, with invented data for a fictional researcher
cv.bib   sample entries for the optional biblatex publication list

License: CC0 1.0. Use it, change it, share it, no credit needed.

Compile (plain publication list, the default):
  pdflatex cv.tex        or        latexmk -pdf cv.tex

Publications from cv.bib instead of the list typed in cv.tex:
  1. In cv.tex, change \usebiblatexfalse to \usebiblatextrue.
  2. Run latexmk -pdf cv.tex (it runs Biber for you).
  3. Each entry in cv.bib has a keywords field (journal, conference or
     working) that decides which heading it prints under.
  biblatex and Biber are not in a minimal install. With BasicTeX or TinyTeX:
  sudo tlmgr install biblatex biber    (TinyTeX: tlmgr install biblatex biber)

Overleaf: upload this zip with New Project > Upload Project. Set the main
document to cv.tex.
