Springer Nature (sn-jnl) starter from purplelink.llc/templates/springer-nature-sn-jnl/

main.tex        the minimal skeleton from the page
references.bib  one example entry; replace it with your own

This download does not include sn-jnl.cls or the .bst files. Get them from
Springer Nature (springernature.com/gp/authors/campaigns/latex-author-support)
or from the Springer Nature template on Overleaf, and put sn-jnl.cls and the
.bst file for your reference style in this folder, next to main.tex.
Keep everything in one flat folder, with no subfolders.

Compile with pdfLaTeX, then BibTeX, then pdfLaTeX twice (or run latexmk -pdf main.tex).

In ModernTex: unzip, then File > Open the folder.
