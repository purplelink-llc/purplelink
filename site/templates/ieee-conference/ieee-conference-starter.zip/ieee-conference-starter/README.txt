IEEE conference starter from purplelink.llc/templates/ieee-conference/

main.tex        the minimal skeleton from the page
references.bib  one example entry; replace it with your own

Compile with pdfLaTeX, then BibTeX, then pdfLaTeX twice (or run latexmk -pdf main.tex).

In ModernTex: unzip, then File > Open the folder.
