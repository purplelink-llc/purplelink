Thesis starter from purplelink.llc/templates/latex-thesis-template/

A university-neutral thesis or dissertation project in the standard LaTeX
book class (one-sided). It is a starting point. Your university's rules
always win: check its formatting guide before you submit.

License: CC0 1.0. Use it, change it, share it, no credit needed. The three
books in references.bib are real; every other name and number is invented.

Files
  main.tex                  settings, front matter, chapter list, bibliography
  frontmatter/              title page, abstract, acknowledgements
  chapters/                 introduction, literature, method, results, conclusion
  appendices/               appendix-a.tex, appendix-b.tex
  figures/placeholder.pdf   a placeholder figure made for this template
  references.bib            sample entries

Compile (pdfLaTeX and BibTeX, not Biber)
  latexmk -pdf main.tex
  Overleaf: New Project > Upload Project, choose this zip, main document main.tex.
  ModernTex, TeXShop, TeXstudio, VS Code: open the folder, build main.tex.

Set margins
  Section 1 of main.tex: \usepackage[margin=1in]{geometry}
  Different sides, for example a wider binding margin:
  \usepackage[left=1.5in,right=1in,top=1in,bottom=1in]{geometry}
  US letter is the default. For A4 change letterpaper to a4paper in
  \documentclass.

Set line spacing
  Section 1 of main.tex: \onehalfspacing. Use \doublespacing or
  \singlespacing instead. Footnotes, captions and block quotes stay
  single-spaced. The bibliography follows the body spacing; wrap it in
  \begin{singlespace} ... \end{singlespace} to tighten it.
  Font size is the 12pt option in \documentclass.

Plug in your university's class or rules
  1. Copy the class file (for example myuniv.cls) next to main.tex.
  2. In main.tex change \documentclass[...]{book} to \documentclass{myuniv}.
  3. Delete or adjust the packages the class already loads. geometry and
     setspace are the usual duplicates. If LaTeX reports an option clash,
     remove the package from main.tex.
  4. Remove frontmatter/titlepage.tex from main.tex if the class makes its
     own title page with \maketitle. Set the title, author and degree the
     way the class's documentation says.
  5. Keep the chapters, appendices and references.bib. They only use
     \chapter, \section, \label, \ref, \cite and standard environments.
  If the university gives no class, only a PDF of rules, change the
  settings in main.tex and the title page file until the PDF matches.

Bibliography
  natbib with BibTeX. \citet{key} gives Author (year), \citep{key} gives
  (Author, year). For numbered citations use
  \usepackage[numbers,sort&compress]{natbib}. To change the reference
  style, change plainnat in \bibliographystyle to another .bst file.

Editors
  Each chapter file starts with % !TEX root = ../main.tex so TeXShop, TeXstudio
  and VS Code build main.tex when you press Typeset inside a chapter.

Leave a chapter out while you work
  Put a % in front of its \input line in main.tex. Cross references to it
  show as ?? until you put it back.

TinyTeX or BasicTeX needs these packages (MacTeX has them all)
  tlmgr install latexmk natbib geometry setspace hyperref booktabs amsmath \
    caption microtype lm ec cm amsfonts graphics etoolbox
  Add sudo for BasicTeX; TinyTeX does not need it.

Tested with TeX Live 2026 (TinyTeX), latexmk -pdf, no errors or warnings.
