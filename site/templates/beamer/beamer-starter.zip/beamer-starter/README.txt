Beamer starter from purplelink.llc/templates/beamer/

slides.tex   16:9 slides with \pause, overlays and speaker notes (Metropolis theme)
poster.tex   A0 portrait poster with beamerposter

Compile each file with latexmk -pdf slides.tex and latexmk -pdf poster.tex.
Both build with a current TeX Live. The Metropolis theme and beamerposter are in TeX Live.
Metropolis uses the Fira Sans font only under XeLaTeX or LuaLaTeX (latexmk -xelatex slides.tex).
With pdfLaTeX it falls back to the default font and prints a warning.

Handout: add handout to the class options of slides.tex.
Speaker notes: uncomment one \setbeameroption line near the top of slides.tex.

In ModernTex: unzip, then File > Open the folder.
