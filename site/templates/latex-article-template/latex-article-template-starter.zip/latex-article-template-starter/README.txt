Article starter from purplelink.llc/templates/latex-article-template/

A plain journal or working-paper article in the standard LaTeX article class.
If a journal gives you its own class or template, use theirs.

License: CC0 1.0. Use it, change it, share it, no credit needed. The three
books in references.bib are real; every other name and number is invented.

Files
  main.tex                  the article
  references.bib            sample entries
  figures/placeholder.pdf   a placeholder figure made for this template

Compile (pdfLaTeX and BibTeX, not Biber)
  latexmk -pdf main.tex
  Overleaf: New Project > Upload Project, choose this zip, main document main.tex.
  ModernTex, TeXShop, TeXstudio, VS Code: open the folder, build main.tex.

Common changes
  Paper size: letterpaper to a4paper in \documentclass.
  Margins: \usepackage[margin=1in]{geometry}.
  Double spacing for a manuscript: add \usepackage{setspace} and
  \doublespacing after it.
  Numbered citations: \usepackage[numbers,sort&compress]{natbib}.
  Reference style: change plainnat in \bibliographystyle to another .bst.
  Appendix: everything after \appendix is lettered (A, B, ...).

Switch to a journal's class
  Replace \documentclass and the title, author and abstract block with what
  the journal's template shows, and remove any package the class already
  loads. Keep the sections, figures, tables and references.bib.

TinyTeX or BasicTeX needs these packages (MacTeX has them all)
  tlmgr install latexmk natbib geometry hyperref booktabs amsmath caption \
    microtype lm ec cm amsfonts graphics etoolbox
  Add sudo for BasicTeX; TinyTeX does not need it.

Tested with TeX Live 2026 (TinyTeX), latexmk -pdf, no errors or warnings.
